// SOCpit - Security Operations Center
// Domain model tests
// Based on MATRIX V3 with xUnit

using SOCpit.Core;
using System;
using Xunit;

namespace SOCpit.Core.Tests
{
    public class DomainTests
    {
        [Fact]
        public void Threat_Create_Valid()
        {
            var threat = Threat.Create(
                id: "threat-001",
                name: "Test Threat",
                description: "Test description",
                severity: ThreatSeverity.Critical,
                status: ThreatStatus.New,
                targetId: "host-001",
                detectedAt: DateTimeOffset.UtcNow,
                source: "Test Source",
                tags: new List<string> { "test", "critical" });

            Assert.NotNull(threat);
            Assert.Equal("threat-001", threat.Id);
            Assert.Equal("Test Threat", threat.Name);
            Assert.Equal("Test description", threat.Description);
            Assert.Equal(ThreatSeverity.Critical, threat.Severity);
            Assert.Equal(ThreatStatus.New, threat.Status);
            Assert.Equal("host-001", threat.TargetId);
            Assert.Equal("Test Source", threat.Source);
            Assert.Equal(2, threat.Tags.Count);
        }

        [Fact]
        public void Threat_Create_InvalidId_Throws()
        {
            Assert.Throws<ArgumentException>(() => Threat.Create(
                id: "",
                name: "Test",
                description: "Test",
                severity: ThreatSeverity.Low,
                status: ThreatStatus.New,
                targetId: "host-001",
                detectedAt: DateTimeOffset.UtcNow,
                source: "Test",
                tags: new List<string>()));
        }

        [Fact]
        public void Threat_ValidateId_Valid()
        {
            var id = Threat.ValidateId("valid-id-123");
            Assert.Equal("valid-id-123", id);
        }

        [Fact]
        public void Threat_ValidateId_Empty_Throws()
        {
            Assert.Throws<ArgumentException>(() => Threat.ValidateId(""));
        }

        [Fact]
        public void Threat_ValidateId_TooLong_Throws()
        {
            var longId = new string('a', 81);
            Assert.Throws<ArgumentException>(() => Threat.ValidateId(longId));
        }

        [Fact]
        public void Vulnerability_Create_Valid()
        {
            var vulnerability = Vulnerability.Create(
                id: "vuln-001",
                cveId: "CVE-2024-1234",
                name: "Test Vulnerability",
                description: "Test description",
                severity: VulnerabilitySeverity.High,
                status: VulnerabilityStatus.Open,
                targetId: "host-001",
                publishedAt: DateTimeOffset.UtcNow);

            Assert.NotNull(vulnerability);
            Assert.Equal("vuln-001", vulnerability.Id);
            Assert.Equal("CVE-2024-1234", vulnerability.CveId);
            Assert.Equal("Test Vulnerability", vulnerability.Name);
            Assert.Equal(VulnerabilitySeverity.High, vulnerability.Severity);
            Assert.Equal(VulnerabilityStatus.Open, vulnerability.Status);
        }

        [Fact]
        public void SecurityIncident_Create_Valid()
        {
            var incident = SecurityIncident.Create(
                id: "incident-001",
                title: "Test Incident",
                description: "Test description",
                severity: IncidentSeverity.Critical,
                status: IncidentStatus.New,
                createdAt: DateTimeOffset.UtcNow,
                assignedTo: "admin",
                relatedThreatIds: new List<string> { "threat-001" },
                relatedVulnerabilityIds: new List<string> { "vuln-001" });

            Assert.NotNull(incident);
            Assert.Equal("incident-001", incident.Id);
            Assert.Equal("Test Incident", incident.Title);
            Assert.Equal(IncidentSeverity.Critical, incident.Severity);
            Assert.Equal(IncidentStatus.New, incident.Status);
            Assert.Equal("admin", incident.AssignedTo);
        }

        [Fact]
        public void Evidence_Create_Valid()
        {
            var evidence = Evidence.Create(
                id: "evidence-001",
                name: "Test Evidence",
                type: EvidenceType.Log,
                description: "Test description",
                status: EvidenceStatus.New,
                classification: EvidenceClassification.Internal,
                source: "Test Source",
                collectedAt: DateTimeOffset.UtcNow,
                sizeBytes: 1024,
                hash: "abc123",
                filePath: "/path/to/file.log",
                tags: new List<string> { "test" });

            Assert.NotNull(evidence);
            Assert.Equal("evidence-001", evidence.Id);
            Assert.Equal("Test Evidence", evidence.Name);
            Assert.Equal(EvidenceType.Log, evidence.Type);
            Assert.Equal(1024, evidence.SizeBytes);
        }

        [Fact]
        public void Host_Create_Valid()
        {
            var host = Host.Create(
                id: "host-001",
                name: "Test Host",
                ipAddress: "192.168.1.1",
                macAddress: "00:00:00:00:00:00",
                type: AssetType.Server,
                status: AssetStatus.Active,
                operatingSystem: OperatingSystemType.Windows,
                createdAt: DateTimeOffset.UtcNow,
                tags: new List<string> { "server" });

            Assert.NotNull(host);
            Assert.Equal("host-001", host.Id);
            Assert.Equal("Test Host", host.Name);
            Assert.Equal("192.168.1.1", host.IpAddress);
            Assert.Equal(AssetType.Server, host.Type);
        }

        [Fact]
        public void Network_Create_Valid()
        {
            var network = Network.Create(
                id: "network-001",
                name: "Test Network",
                cidr: "192.168.1.0/24",
                description: "Test network",
                type: "Internal",
                tags: new List<string> { "internal" });

            Assert.NotNull(network);
            Assert.Equal("network-001", network.Id);
            Assert.Equal("Test Network", network.Name);
            Assert.Equal("192.168.1.0/24", network.Cidr);
        }

        [Fact]
        public void User_Create_Valid()
        {
            var user = User.Create(
                id: "user-001",
                username: "testuser",
                email: "test@example.com",
                fullName: "Test User",
                role: UserRole.Analyst,
                status: UserStatus.Active,
                authenticationType: AuthenticationType.Local,
                createdAt: DateTimeOffset.UtcNow,
                tags: new List<string> { "analyst" });

            Assert.NotNull(user);
            Assert.Equal("user-001", user.Id);
            Assert.Equal("testuser", user.Username);
            Assert.Equal("test@example.com", user.Email);
            Assert.Equal(UserRole.Analyst, user.Role);
        }

        [Fact]
        public void AuditLog_Create_Valid()
        {
            var auditLog = AuditLog.Create(
                id: "audit-001",
                action: "Create",
                entityType: "Threat",
                entityId: "threat-001",
                userId: "admin",
                timestamp: DateTimeOffset.UtcNow,
                details: "Created threat");

            Assert.NotNull(auditLog);
            Assert.Equal("audit-001", auditLog.Id);
            Assert.Equal("Create", auditLog.Action);
            Assert.Equal("Threat", auditLog.EntityType);
        }

        [Fact]
        public void SecurityControl_Create_Valid()
        {
            var control = SecurityControl.Create(
                id: "control-001",
                name: "Test Control",
                description: "Test description",
                type: SecurityControlType.Preventive,
                category: "Access Control",
                required: true,
                scope: "All Systems",
                implementation: "Firewall Rules");

            Assert.NotNull(control);
            Assert.Equal("control-001", control.Id);
            Assert.Equal("Test Control", control.Name);
            Assert.Equal(SecurityControlType.Preventive, control.Type);
        }

        [Fact]
        public void ComplianceCheck_Create_Valid()
        {
            var check = ComplianceCheck.Create(
                id: "check-001",
                standard: "ISO 27001",
                requirement: "Access Control",
                status: ComplianceStatus.Compliant,
                targetId: "host-001",
                checkedAt: DateTimeOffset.UtcNow);

            Assert.NotNull(check);
            Assert.Equal("check-001", check.Id);
            Assert.Equal("ISO 27001", check.Standard);
            Assert.Equal(ComplianceStatus.Compliant, check.Status);
        }

        [Fact]
        public void NetworkConnection_Create_Valid()
        {
            var connection = NetworkConnection.Create(
                id: "conn-001",
                sourceIp: "192.168.1.1",
                sourcePort: 1234,
                destinationIp: "192.168.1.2",
                destinationPort: 80,
                protocol: NetworkProtocol.TCP,
                establishedAt: DateTimeOffset.UtcNow);

            Assert.NotNull(connection);
            Assert.Equal("conn-001", connection.Id);
            Assert.Equal("192.168.1.1", connection.SourceIp);
            Assert.Equal(1234, connection.SourcePort);
        }

        [Fact]
        public void Service_Create_Valid()
        {
            var service = Service.Create(
                id: "service-001",
                name: "Test Service",
                description: "Test service",
                type: "Web",
                hostIds: new List<string> { "host-001" },
                ports: new List<int> { 80, 443 },
                status: "Running",
                tags: new List<string> { "web" });

            Assert.NotNull(service);
            Assert.Equal("service-001", service.Id);
            Assert.Equal("Test Service", service.Name);
            Assert.Equal(2, service.Ports.Count);
        }

        [Fact]
        public void Application_Create_Valid()
        {
            var app = Application.Create(
                id: "app-001",
                name: "Test Application",
                description: "Test application",
                version: "1.0.0",
                vendor: "Test Vendor",
                type: "Web",
                tags: new List<string> { "web" });

            Assert.NotNull(app);
            Assert.Equal("app-001", app.Id);
            Assert.Equal("Test Application", app.Name);
            Assert.Equal("1.0.0", app.Version);
        }
    }
}
