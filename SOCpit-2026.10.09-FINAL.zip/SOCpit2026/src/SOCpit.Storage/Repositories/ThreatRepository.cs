// SOCpit - Security Operations Center
// Threat repository implementation
// Based on MATRIX V3 with repository pattern

using Microsoft.EntityFrameworkCore;
using SOCpit.Application.Repositories;
using SOCpit.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace SOCpit.Storage.Repositories
{
    /// <summary>Repository implementation for threats.</summary>
    public sealed class ThreatRepository : BaseRepository<Threat>, IThreatRepository
    {
        public ThreatRepository(SOCpitDbContext dbContext) : base(dbContext)
        {
        }

        public override async Task<Threat> AddAsync(Threat threat, CancellationToken cancellationToken = default)
        {
            await _dbSet.AddAsync(threat, cancellationToken);
            return threat;
        }

        public override async Task<Threat?> GetByIdAsync(string id, CancellationToken cancellationToken = default)
        {
            return await _dbSet.FindAsync(new[] { id }, cancellationToken);
        }

        public async Task<IReadOnlyList<Threat>> GetBySeverityAsync(ThreatSeverity severity, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(t => t.Severity == severity)
                .ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Threat>> GetByStatusAsync(ThreatStatus status, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(t => t.Status == status)
                .ToListAsync(cancellationToken);
        }

        public async Task<IReadOnlyList<Threat>> GetByTargetIdAsync(string targetId, CancellationToken cancellationToken = default)
        {
            return await _dbSet
                .Where(t => t.TargetId == targetId)
                .ToListAsync(cancellationToken);
        }

        public override async Task<Threat> UpdateAsync(Threat threat, CancellationToken cancellationToken = default)
        {
            _dbSet.Update(threat);
            return threat;
        }

        public override async Task<bool> DeleteAsync(string id, CancellationToken cancellationToken = default)
        {
            var threat = await GetByIdAsync(id, cancellationToken);
            if (threat == null)
                return false;

            _dbSet.Remove(threat);
            return true;
        }

        public override async Task<int> CountAsync(CancellationToken cancellationToken = default)
        {
            return await _dbSet.CountAsync(cancellationToken);
        }
    }
}
