// SOCpit - Security Operations Center
// Main window for WPF application
// Based on MATRIX V3 with MVVM pattern

using SOCpit.App.ViewModels;
using SOCpit.App.Views;
using System.Windows;

namespace SOCpit.App
{
    /// <summary>Interaction logic for MainWindow.xaml</summary>
    public partial class MainWindow : Window
    {
        public MainWindow(MainViewModel viewModel)
        {
            InitializeComponent();
            DataContext = viewModel;
        }
    }
}
