// SOCpit - Security Operations Center
// Application entry point
// Based on MATRIX V3 with WPF

using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using SOCpit.Application.Repositories;
using SOCpit.Application.Services;
using SOCpit.Import.Importers;
using SOCpit.Import.Exporters;
using SOCpit.Storage;
using SOCpit.Storage.Repositories;
using System;
using System.IO;
using System.Windows;

namespace SOCpit.App
{
    /// <summary>Interaction logic for App.xaml</summary>
    public partial class App : Application
    {
        public static IServiceProvider? ServiceProvider { get; private set; }
        public static string AppDataPath { get; } = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
            "SOCpit2026");
        public static string DatabasePath { get; } = Path.Combine(AppDataPath, "socpit.db");

        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            // Ensure application data directory exists
            Directory.CreateDirectory(AppDataPath);

            // Configure services
            var services = new ServiceCollection();
            ConfigureServices(services);
            ServiceProvider = services.BuildServiceProvider();

            // Initialize database
            InitializeDatabase();
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Add logging
            services.AddLogging(logging =>
            {
                logging.AddDebug();
                logging.AddConsole();
            });

            // Add configuration
            services.AddSingleton<IConfiguration>(new ConfigurationBuilder()
                .SetBasePath(AppDataPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                .Build());

            // Add database context
            services.AddDbContext<SOCpitDbContext>(options =>
            {
                options.UseSqlite("Data Source=" + DatabasePath);
                options.UseQueryTrackingBehavior(QueryTrackingBehavior.TrackAll);
            });

            // Add repositories
            services.AddScoped<IThreatRepository, ThreatRepository>();
            services.AddScoped<IVulnerabilityRepository, VulnerabilityRepository>();
            services.AddScoped<IIncidentRepository, IncidentRepository>();
            services.AddScoped<IEvidenceRepository, EvidenceRepository>();
            services.AddScoped<IHostRepository, HostRepository>();
            services.AddScoped<INetworkRepository, NetworkRepository>();
            services.AddScoped<IUserRepository, UserRepository>();
            services.AddScoped<IAuditLogRepository, AuditLogRepository>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            // Add services
            services.AddScoped<ThreatService>();
            services.AddScoped<VulnerabilityService>();
            services.AddScoped<IncidentService>();
            services.AddScoped<EvidenceService>();
            services.AddScoped<HostService>();
            services.AddScoped<NetworkService>();
            services.AddScoped<UserService>();
            services.AddScoped<AuditService>();

            // Add importers and exporters
            services.AddScoped<MatrixImporter>();
            services.AddScoped<MatrixExporter>();

            // Add view models
            services.AddScoped<MainViewModel>();
            services.AddScoped<DashboardViewModel>();
            services.AddScoped<ThreatsViewModel>();
            services.AddScoped<VulnerabilitiesViewModel>();
            services.AddScoped<IncidentsViewModel>();
            services.AddScoped<EvidenceViewModel>();
            services.AddScoped<HostsViewModel>();
            services.AddScoped<NetworksViewModel>();
            services.AddScoped<UsersViewModel>();
            services.AddScoped<ReportsViewModel>();
            services.AddScoped<SettingsViewModel>();
        }

        private void InitializeDatabase()
        {
            try
            {
                using var scope = ServiceProvider!.CreateScope();
                var dbContext = scope.ServiceProvider.GetRequiredService<SOCpitDbContext>();
                dbContext.Database.EnsureCreated();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Database initialization failed: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
