# SOCpit - Security Operations Center

![SOCpit Logo](https://via.placeholder.com/100x100/0078D7/FFFFFF?text=SOCpit)

**SOCpit** is a comprehensive Security Operations Center (SOC) application designed for threat detection, vulnerability management, incident response, and security monitoring. Built on .NET 10 with WPF for the user interface, SOCpit provides a complete solution for security teams to monitor, analyze, and respond to security events.

## Features

### Core Capabilities
- **Threat Management**: Detect, track, and manage security threats with severity levels and status tracking
- **Vulnerability Scanning**: Import, track, and manage vulnerabilities with CVE integration
- **Incident Response**: Create, track, and resolve security incidents with full audit trail
- **Evidence Collection**: Store and manage security evidence (logs, screenshots, network captures, files)
- **Asset Management**: Track hosts, networks, services, and applications
- **User Management**: Role-based access control with authentication support
- **Reporting**: Generate comprehensive security reports
- **Audit Logging**: Complete audit trail of all actions

### MATRIX Integration
- Import data from MATRIX V3 project
- Export data to MATRIX-compatible formats
- Automatic mapping between MATRIX and SOCpit data models

## Architecture

```
SOCpit.Application
├── Commands/          # CQRS Command handlers
├── Queries/           # CQRS Query handlers  
├── Services/          # Application services
└── ViewModels/        # WPF ViewModels (MVVM)

SOCpit.Core
├── DomainModels.cs    # Core domain entities
├── SecurityModels.cs  # Security-specific models
├── EvidenceModels.cs  # Evidence and audit models
├── InfrastructureModels.cs # Infrastructure models
└── UserModels.cs      # User and identity models

SOCpit.Storage
├── SOCpitDbContext.cs # Entity Framework Core context
├── Repositories/      # Repository implementations
│   ├── BaseRepository.cs
│   ├── ThreatRepository.cs
│   └── ...
└── UnitOfWork.cs     # Unit of Work pattern

SOCpit.Import
├── Importers/        # Data importers
│   └── MatrixImporter.cs
├── Exporters/        # Data exporters
│   └── MatrixExporter.cs
└── Mappers/          # Data mappers
    └── MatrixMapper.cs

SOCpit.App
├── Views/            # WPF Views
├── ViewModels/       # WPF ViewModels
├── Themes/           # XAML themes and styles
├── Converters/       # Value converters
└── App.xaml          # Application entry point
```

## Quick Start

### Prerequisites
- .NET 10 SDK
- Windows 10/11 (for WPF)
- SQLite (included with .NET)

### Installation
1. Clone the repository:
   ```bash
   git clone https://github.com/aifirsts/SOCpit2026.git
   cd SOCpit2026
   ```

2. Restore dependencies:
   ```bash
   dotnet restore
   ```

3. Build the solution:
   ```bash
   dotnet build
   ```

4. Run the application:
   ```bash
   cd src/SOCpit.App
   dotnet run
   ```

### Configuration
The application stores data in `%LocalAppData%\SOCpit2026\socpit.db` by default. You can configure the data storage path in the Settings view.

## Usage

### Dashboard
The dashboard provides an overview of:
- Total threats by severity
- Total vulnerabilities by severity
- Open incidents count
- Active hosts count
- Recent threats, vulnerabilities, and incidents

### Threats Module
- View all threats with filtering by severity and status
- Add, edit, and delete threats
- Link threats to targets and evidence
- Track threat lifecycle

### Vulnerabilities Module
- Import vulnerabilities from MATRIX or other sources
- Track vulnerability status and severity
- Link to CVEs and references
- Monitor fix availability

### Incidents Module
- Create and manage security incidents
- Link incidents to threats and vulnerabilities
- Track incident resolution
- Document impact analysis and lessons learned

### Evidence Module
- Upload and store security evidence
- Classify evidence by type and sensitivity
- Link evidence to incidents, threats, and vulnerabilities
- Calculate file hashes for integrity verification

### Hosts & Networks Module
- Manage inventory of hosts and network devices
- Track IP addresses, MAC addresses, and operating systems
- Organize hosts into networks and subnets
- Monitor host status

### Users Module
- Manage user accounts with role-based access
- Support for multiple authentication types
- Lock/unlock user accounts
- Audit user actions

### Reports Module
- Generate predefined security reports
- Custom date range filtering
- Export reports to various formats
- Schedule automated report generation

### Settings Module
- Configure data storage paths
- Set backup frequency
- Select language and theme
- View audit logs
- Test database connectivity

## MATRIX Integration

### Import from MATRIX V3
1. Prepare your MATRIX data in JSON format:
   - `hosts.json` - List of host assets
   - `networks.json` - List of network configurations
   - `threats.json` - List of detected threats
   - `vulnerabilities.json` - List of vulnerabilities
   - `incidents.json` - List of security incidents
   - `evidence.json` - List of evidence files

2. Use the MatrixImporter service:
   ```csharp
   var importer = new MatrixImporter(unitOfWork, logger);
   var config = new MatrixImporter.ImportConfig
   {
       SourcePath = "path/to/matrix/data",
       ImportHosts = true,
       ImportNetworks = true,
       ImportThreats = true,
       ImportVulnerabilities = true,
       ImportIncidents = true,
       ImportEvidence = true
   };
   var result = await importer.ImportAllAsync(config);
   ```

### Export to MATRIX Format
```csharp
var exporter = new MatrixExporter(unitOfWork, logger);
var config = new MatrixExporter.ExportConfig
{
    ExportPath = "path/to/export",
    ExportHosts = true,
    ExportNetworks = true,
    ExportThreats = true,
    ExportVulnerabilities = true,
    ExportIncidents = true,
    ExportEvidence = true,
    ExportUsers = true
};
var result = await exporter.ExportAllAsync(config);
```

## Data Model

### Entity Relationships
```
Threat
├── belongs to Target (Host/Network)
├── has related Evidence
└── can be linked to Incident

Vulnerability
├── belongs to Target (Host/Application)
├── has CVE ID
├── has References
└── can be linked to Incident

SecurityIncident
├── has related Threats
├── has related Vulnerabilities
├── has related Evidence
└── assigned to User

Evidence
├── belongs to Incident/Threat/Vulnerability
├── has FilePath
├── has Hash (SHA256)
└── has Classification

Host
├── belongs to Network
├── has OperatingSystem
├── has IP/MAC addresses
└── can have Vulnerabilities

Network
├── has Subnets
├── has VLANs
└── contains Hosts

User
├── has Role
├── has Permissions
└── can be assigned to Incidents
```

## Security Features

### Authentication & Authorization
- Role-based access control (RBAC)
- Multiple authentication types supported:
  - Local authentication
  - LDAP/Active Directory
  - OAuth/SAML
  - Certificate-based
  - Multi-factor authentication

### Data Protection
- Evidence classification levels:
  - Public
  - Internal
  - Confidential
  - Restricted
- File integrity verification with SHA256 hashing
- Audit logging of all sensitive operations

### Security Controls
- Preventive, Detective, Corrective, Deterrent, Recovery, Compensating
- Verification methods and frequency
- Compliance status tracking

## API Reference

### Services
All services follow the repository pattern and support:
- `GetAllAsync()` - Get all entities
- `GetByIdAsync(id)` - Get entity by ID
- `AddAsync(entity)` - Add new entity
- `UpdateAsync(entity)` - Update existing entity
- `DeleteAsync(id)` - Delete entity
- Filter methods for common queries

### Example: Threat Service
```csharp
// Create a threat
var threat = await threatService.CreateAsync(
    name: "Suspicious Login Attempt",
    description: "Multiple failed login attempts detected",
    severity: ThreatSeverity.High,
    status: ThreatStatus.New,
    targetId: "host-001",
    source: "SIEM",
    tags: new List<string> { "authentication", "brute-force" });

// Get all threats
var threats = await threatService.GetAllAsync();

// Get threats by severity
var criticalThreats = await threatService.GetBySeverityAsync(ThreatSeverity.Critical);

// Update threat
var updated = await threatService.UpdateAsync(
    id: "threat-001",
    status: ThreatStatus.Investigating,
    assignedTo: "analyst-001");

// Delete threat
var deleted = await threatService.DeleteAsync("threat-001");
```

## Deployment

### Single-File Deployment (Recommended)
```bash
cd src/SOCpit.App
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:PublishTrimmed=true
```

This creates a single `SOCpit.App.exe` file that can be deployed to any Windows machine with the .NET 10 runtime.

### Configuration Files
- `appsettings.json` - Application configuration
- `socpit.db` - SQLite database (default location: `%LocalAppData%\SOCpit2026`)

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## Support

For support, please open an issue on the GitHub repository or contact the maintainers.

## Versioning

SOCpit uses date-based versioning: `YYYY.MM.DD`

Current version: **2026.10.09**

## Roadmap

- [x] Core domain models
- [x] Repository pattern implementation
- [x] Service layer
- [x] WPF UI with MVVM
- [x] MATRIX integration
- [x] SQLite persistence
- [ ] REST API (future)
- [ ] Real-time monitoring (future)
- [ ] Machine learning integration (future)
- [ ] Cloud deployment support (future)

## Acknowledgments

- Inspired by MATRIX V3 project
- Built with .NET 10 and WPF
- Uses Entity Framework Core for data access
- Follows CQRS and Repository patterns
- Implements MVVM for UI

---

**SOCpit - Your Comprehensive Security Operations Center**

Copyright (c) 2026 aifirsts
